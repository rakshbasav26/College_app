class AddCityToCounselingForms < ActiveRecord::Migration[7.1]
  def change
    add_column :counseling_forms, :city, :string
  end
end
