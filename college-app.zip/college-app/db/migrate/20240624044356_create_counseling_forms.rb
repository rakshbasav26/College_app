class CreateCounselingForms < ActiveRecord::Migration[7.1]
  def change
    create_table :counseling_forms do |t|
      t.string :name
      t.integer :marks

      t.timestamps
    end
  end
end
