class AddCutoffMarkToCounselingForms < ActiveRecord::Migration[7.1]
  def change
    add_column :counseling_forms, :cutoff_mark, :integer
  end
end
