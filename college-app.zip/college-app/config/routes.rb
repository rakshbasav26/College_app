Rails.application.routes.draw do
  resources :users do
    member do
     get 'selected_seats'
     get 'allot_college'
     post 'assign_college'
   end
 end

  get 'get_started', to: 'colleges#get_started'

  resources :counseling_forms


  resources :profiles
  get 'login', to: 'sessions#new', as: 'login'
  post 'login', to: 'sessions#create'
  get 'logout', to: 'sessions#destroy'
  delete 'logout', to: 'sessions#destroy'

   resources :colleges do
     resources :departments do
       post 'select_seat', on: :member
     end
   end

  root 'colleges#index'
end
