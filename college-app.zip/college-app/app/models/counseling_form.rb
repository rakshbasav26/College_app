class CounselingForm < ApplicationRecord
  belongs_to :user
end
