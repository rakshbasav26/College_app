class User < ApplicationRecord	
  has_secure_password

  has_and_belongs_to_many :colleges, join_table: :colleges_users
  has_many :departments
  has_one :counseling_form



  validates :email, presence: true, uniqueness: true
  validates :password, presence: true, length: { minimum: 6 } 
  has_many :seat_selections
  has_many :selected_departments, through: :seat_selections, source: :department



  def admin?
    self.admin
  end


  def selected_colleges
    College.joins(departments: :seat_selections).where(seat_selections: { user_id: id }).distinct
  end
end
