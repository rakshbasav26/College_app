class Department < ApplicationRecord
  belongs_to :college
  has_many :seat_selections
  has_many :users, through: :seat_selections
  validates :name, presence: true
  validates :seats, presence: true, numericality: { only_integer: true }
end

