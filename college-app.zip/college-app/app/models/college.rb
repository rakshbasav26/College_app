class College < ApplicationRecord
  has_many :departments, dependent: :destroy

  has_many :departments
  has_many :seat_selections
  has_many :users, through: :seat_selections



  validates :name, presence: true
  validates :city, presence: true
  validates :cutoff_mark, presence: true
end
