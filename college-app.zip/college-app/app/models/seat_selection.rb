class SeatSelection < ApplicationRecord
  belongs_to :user
  belongs_to :department
  

  validates :user_id, uniqueness: { scope: :department_id, message: "can only select one seat per department" }
end
