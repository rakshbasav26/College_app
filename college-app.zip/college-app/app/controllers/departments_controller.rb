class DepartmentsController < ApplicationController
  before_action :set_college
  before_action :require_user_logged_in!, :current_user
  before_action :set_department, only: [:show, :edit, :update, :destroy]

  def index
    @departments = @college.departments
  end

  def show
  end

  def new
    @department = @college.departments.build
  end

  def create
    @department = @college.departments.build(department_params)
    if @department.save
      redirect_to root_path
      flash[:notice] = 'Department was successfully created.'
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @department.update(department_params)
      redirect_to root_path, notice: 'Department was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    @department.destroy
    redirect_to root_path, notice: 'Department was successfully destroyed.'
  end

   def select_seat
    @department = Department.find(params[:id])

    if current_user.selected_departments.include?(@department)
      flash[:alert] = "You have already selected a seat in this department."
    elsif @department.seats > 0
      @department.with_lock do
        @department.update!(seats: @department.seats - 1)
        SeatSelection.create!(user: current_user, department: @department)
      end
      flash[:notice] = "Seat selected successfully."
    else
      flash[:alert] = "No seats available in this department."
    end

    redirect_to college_path(@college)
  end
  private

  def set_college
    @college = College.find(params[:college_id])
  end

  def set_department
    @department = @college.departments.find(params[:id])
  end

  def department_params
    params.require(:department).permit(:name, :seats)
  end
  
end
