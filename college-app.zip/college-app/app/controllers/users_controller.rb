class UsersController < ApplicationController
  before_action :require_user_logged_in!, except: [:new, :create]
  before_action :require_admin, only: [:index, :show, :destroy] 

  def new
    @user = User.new
  end
  
  def create
    @user = User.new(user_params)
    if @user.save
      session[:user_id] = @user.id
      session[:name] = @user.name  
      redirect_to get_started_path, notice: 'Account created successfully.'
    else
      render :new
    end
  end

  def index
    @users = User.all
  end

  def show
    @user = User.find(params[:id])
    @selected_colleges = @user.selected_colleges
    @selected_departments = @user.selected_departments
    @selected_seats = @user.seat_selections
 end

  def destroy
    @user = User.find(params[:id])
    @user.destroy
    session[:user_id] = nil if current_user == @user 
    redirect_to root_path, notice: "User deleted successfully."
  end

  def selected_seats
    if current_user
      @selected_colleges = current_user.selected_colleges.includes(:departments)
      @selected_seats = current_user.seat_selections
    else
      redirect_to login_path, alert: "You need to sign in to view selected seats."
    end
  end

  
  private

  def user_params
    params.require(:user).permit(:name, :email, :password, :password_confirmation)
  end

  def require_admin
    unless current_user&.admin?
      redirect_to root_path, alert: "You are not authorized to access this section."
    end
  end
end
