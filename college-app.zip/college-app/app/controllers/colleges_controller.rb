class CollegesController < ApplicationController
  before_action :set_college, only: [:show, :edit, :update, :destroy]
  
  def index
    @colleges = College.all
    
    if current_user
      if params[:cutoff].present? && params[:city].present?
        cutoff_value = params[:cutoff].to_i
        city_value = params[:city]
        @colleges = @colleges.where("cutoff_mark <= ? AND city LIKE ?", cutoff_value, "%#{city_value}%")
      end
    end
  end

  def show
    @college = College.includes(:departments).find(params[:id])
  end

  def new
    @college = College.new
  end

  def edit
  end

  def create
    @college = College.new(college_params)
    if @college.save
      redirect_to root_path
      flash[:notice] = "College was created successfully."
    else
      render :new
    end
  end

  def update
    if @college.update(college_params)
      redirect_to @college
      flash[:notice] = 'College was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    @college.destroy
    redirect_to colleges_url, notice: 'College was successfully destroyed.'
  end

  def get_started
  end

  private

  def set_college
    @college = College.find(params[:id])
  end

  def college_params
    params.require(:college).permit(:name, :city, :cutoff_mark)
  end
end
