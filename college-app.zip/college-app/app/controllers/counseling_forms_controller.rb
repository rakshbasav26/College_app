class CounselingFormsController < ApplicationController
  def new
    @counseling_form = CounselingForm.new
    @user_name = session[:name]
  end

  def index
     @counseling_form = CounselingForm.all
  end

  def create
    if current_user
      @counseling_form = current_user.build_counseling_form(counseling_form_params) 

      if @counseling_form.save
        redirect_to colleges_path, notice: 'Counseling form was successfully created.'
      else
        flash.now[:alert] = @counseling_form.errors.full_messages.to_sentence
        render :new
      end
    else
      redirect_to login_path, alert: "You need to be logged in to submit a counseling form."
    end
  end

  def show 
    @counseling_form = CounselingForm.find(params[:id])
  end

  def edit
    @counseling_form = current_user.counseling_form
  end

  def update
    @counseling_form = current_user.counseling_form
    if @counseling_form.update(counseling_form_params)
      redirect_to root_path
    else
      render :edit
    end
  end




  private

  def counseling_form_params
    params.require(:counseling_form).permit(:name, :marks, :cutoff_mark, :city)
  end
end
