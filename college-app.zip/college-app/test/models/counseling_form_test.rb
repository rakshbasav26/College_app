require "test_helper"

class CounselingFormTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
