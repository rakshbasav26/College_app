require "test_helper"

class SeatSelectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
